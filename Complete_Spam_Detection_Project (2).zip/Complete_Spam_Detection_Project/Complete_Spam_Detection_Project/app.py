
from flask import Flask, render_template, request
from main import classify_message

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def home():
    result = None
    score = None
    indicators = []

    if request.method == "POST":
        message = request.form.get("message", "").strip()

        if message:
            result, score, indicators = classify_message(message)

    return render_template(
        "index.html",
        result=result,
        score=score,
        indicators=indicators
    )

if __name__ == "__main__":
    app.run(debug=True)
