EMAIL / SMS SPAM DETECTION - COMPLETE DEMONSTRATION PROJECT
==========================================================

IMPORTANT DATASET NOTE
----------------------
This ZIP includes data/sms_spam_demo_dataset.csv with 1,500 preloaded,
synthetically generated teaching examples (900 ham and 600 spam).
It is NOT the original UCI SMS Spam Collection and does not contain real
people's messages. It is included so the project runs immediately without
downloading or adding any files.

PROJECT TYPE
------------
Rule-based text classification. It does not use Naive Bayes, TF-IDF, or a
trained machine-learning model. The indicator rules and point scores are
visible in main.py so they can be explained in a viva.

HOW TO RUN (Python 3.8+)
------------------------
1. Extract the ZIP.
2. Open the extracted folder in VS Code.
3. Open Terminal in that folder.
4. Install packages:
       pip install -r requirements.txt
5. Run:
       python main.py

OUTPUTS
-------
outputs/prediction_results.csv
outputs/confusion_matrix.png
outputs/evaluation_report.txt

Only one graph is generated: the confusion matrix.

HOW CLASSIFICATION WORKS
------------------------
The program scans each message for indicators and adds points:
- Prize / winner / won / reward: +3
- Free / promotion / offer / voucher / gift / deal: +2
- Urgent / limited time / act now / expiry wording: +2
- Currency amount / cash / bonus: +3
- Link-like offer domain: +2
- Call / claim / collect / verify details: +1
- Subscription / STOP / opt-out wording: +1

If the total score is 3 or more, the message is labelled SPAM.
If the score is below 3, it is labelled HAM.

These are simple demonstration rules, not universal spam definitions.
A legitimate message can contain an indicator, and a spam message may avoid
these words. Never treat a message as safe solely because it is labelled HAM.

DATASET COLUMNS
---------------
label: expected class (ham or spam)
message: text message content

The program evaluates predictions against the dataset labels and saves
a confusion matrix and a text evaluation report.
