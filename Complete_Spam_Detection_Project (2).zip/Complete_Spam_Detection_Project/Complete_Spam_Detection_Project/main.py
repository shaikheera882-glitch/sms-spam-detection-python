
from pathlib import Path
import re
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score, ConfusionMatrixDisplay
from sklearn.model_selection import train_test_split

BASE_DIR = Path(__file__).resolve().parent
DATA_FILE = BASE_DIR / "data" / "sms_spam_demo_dataset.csv"
OUTPUT_DIR = BASE_DIR / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)

# Transparent keyword/pattern indicators. These are heuristic signals, not proof.
INDICATORS = {
    "prize_or_winner": (r"\b(prize|winner|won|win|reward)\b", 3),
    "free_or_promotion": (r"\b(free|promotion|offer|voucher|gift|deal)\b", 2),
    "urgency": (r"\b(urgent|limited time|act now|final reminder|expires|before it expires)\b", 2),
    "money_or_bonus": (r"(₹|£|\$)\s?\d+|\b(cash|bonus|prize money)\b", 3),
    "suspicious_link": (r"\b(?:https?://)?(?:[a-z0-9-]+\.)?(?:test|example)\b", 2),
    "call_or_claim": (r"\b(call|claim|collect|verify your details)\b", 1),
    "subscription_or_optout": (r"\b(subscription|reply stop|opt out)\b", 1),
}

SPAM_THRESHOLD = 3

def classify_message(message):
    text = str(message).lower()
    score = 0
    matched = []
    for name, (pattern, points) in INDICATORS.items():
        if re.search(pattern, text, flags=re.IGNORECASE):
            score += points
            matched.append(name)
    label = "spam" if score >= SPAM_THRESHOLD else "ham"
    return label, score, matched

def main():
    if not DATA_FILE.exists():
        raise FileNotFoundError(f"Dataset file not found: {DATA_FILE}")
    df = pd.read_csv(DATA_FILE)
    required = {"label", "message"}
    if not required.issubset(df.columns):
        raise ValueError("Dataset must contain label and message columns.")
    df = df.dropna(subset=["label", "message"]).copy()
    df["label"] = df["label"].str.lower().str.strip()
    df = df[df["label"].isin(["ham", "spam"])]
    df = df.drop_duplicates(subset=["message"]).reset_index(drop=True)

    predictions = df["message"].apply(classify_message)
    df["predicted_label"] = predictions.apply(lambda x: x[0])
    df["spam_score"] = predictions.apply(lambda x: x[1])
    df["matched_indicators"] = predictions.apply(lambda x: ", ".join(x[2]) if x[2] else "none")

    y_true, y_pred = df["label"], df["predicted_label"]
    accuracy = accuracy_score(y_true, y_pred)
    report = classification_report(y_true, y_pred, labels=["ham", "spam"], zero_division=0)

    result_path = OUTPUT_DIR / "prediction_results.csv"
    df.to_csv(result_path, index=False, encoding="utf-8")

    cm = confusion_matrix(y_true, y_pred, labels=["ham", "spam"])
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=["Ham", "Spam"])
    disp.plot(cmap="Blues", values_format="d")
    plt.title("Spam Detection - Confusion Matrix")
    plt.tight_layout()
    graph_path = OUTPUT_DIR / "confusion_matrix.png"
    plt.savefig(graph_path, dpi=160)
    plt.close()

    summary = (
        "SPAM DETECTION PROJECT RESULTS\n"
        "=============================\n"
        f"Records evaluated: {len(df)}\n"
        f"Actual ham: {(y_true == 'ham').sum()}\n"
        f"Actual spam: {(y_true == 'spam').sum()}\n"
        f"Accuracy: {accuracy * 100:.2f}%\n\n"
        "CLASSIFICATION REPORT\n"
        f"{report}\n"
        "Note: This is a rule-based demonstration model evaluated on a synthetic teaching dataset.\n"
        "The scores should not be interpreted as real-world performance.\n"
    )
    (OUTPUT_DIR / "evaluation_report.txt").write_text(summary, encoding="utf-8")
    print(summary)
    print(f"Saved: {result_path}")
    print(f"Saved: {graph_path}")

if __name__ == "__main__":
    main()
