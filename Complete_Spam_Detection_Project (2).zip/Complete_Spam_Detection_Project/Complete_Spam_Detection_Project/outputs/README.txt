Run main.py to generate prediction_results.csv, confusion_matrix.png, and evaluation_report.txt.
